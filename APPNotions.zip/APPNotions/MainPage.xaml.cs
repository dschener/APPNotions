﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;
using Xamarin.Essentials;
using OneSignalSDK.Xamarin;
using OneSignalSDK.Xamarin.Core;


namespace APPNotions
{
    public partial class MainPage : ContentPage
    {
        public MainPage(string url = null)
        {
            InitializeComponent();

            if (string.IsNullOrEmpty(url))
            {
                Navegador.Source = Config.urlLogin;
            }
            else
            {
                Navegador.Source = url;
            }
        }
        void OnBack(object sender, EventArgs args)
        {
            Navegador.GoBack();
        }

        protected override bool OnBackButtonPressed()
        {
            if (Navegador.CanGoBack)
            {
                Navegador.GoBack();
                return true;
            }
            else return base.OnBackButtonPressed();
        }


        async void Navegador_Navigating(object sender, WebNavigatingEventArgs e)
        {
            var current = Connectivity.NetworkAccess;

            if (current == NetworkAccess.Internet)
            {
                NavigationPage.SetHasNavigationBar(this, !e.Url.Contains(Config.dominio) || e.Url.Contains("target=back"));
                if (e.Url.Contains("logout"))
                {
                    await OneSignal.Default.SendTag("tokenUsuario", "logout");
                    Navegador.Source = Config.urlLogin;
                }
                if (e.Url.Contains("token"))
                {
                    string token = e.Url.Split(new string[] { "token=" }, StringSplitOptions.None)[1];
                    await OneSignal.Default.SendTag("tokenUsuario", token);
                }
                if (e.Url.Contains("target=browser") || e.Url.StartsWith("tel:"))
                {
                    NavigationPage.SetHasNavigationBar(this, false);
                    try
                    {
                        await Launcher.OpenAsync(new Uri(e.Url));
                        if (Device.RuntimePlatform == Device.iOS)
                        {
                            Navegador.GoBack();
                        }
                        else if (Device.RuntimePlatform == Device.Android)
                        {
                            e.Cancel = true;
                        }
                    }
                    catch
                    {

                    }
                }
                if (e.Url.Contains("Coordenadas=Coordenadas"))
                {
                    RedireccionConCoordenadas(e.Url);
                }
                if (e.Url.Contains("Coordenadas=ExactasCoordenadas"))
                {
                    RedireccionConCoordenadasExactas(e.Url);
                }
            }
            else
            {
                var browser = new WebView();
                var htmlSource = new HtmlWebViewSource();
                htmlSource.Html = @"<html><body>
                  <h1>No tienes internet</h1><br/>
                  <a href='" + Config.urlLogin + @"'>Reintentar</a>
                  </body></html>";
                Navegador.Source = htmlSource;
            }
        }

        public async Task RedireccionConCoordenadas(string urlOriginal)
        {
            var Latitude = double.Parse("0");
            var Longitude = double.Parse("0");
            string url = urlOriginal.Replace("Coordenadas=Coordenadas", "Paso=1");
            var location = await Geolocation.GetLastKnownLocationAsync();
            url = urlOriginal.Replace("Paso=1", "Paso=2");
            if (location != null)
            {
                Latitude = location.Latitude;
                Longitude = location.Longitude;
            }
            url = urlOriginal.Replace("Paso=1", "Paso=3");
            url = urlOriginal.Replace("Coordenadas=Coordenadas", "Coordenadas=" + Latitude.ToString() + "," + Longitude.ToString());
            Navegador.Source = url;
        }
        public async Task RedireccionConCoordenadasExactas(string urlOriginal)
        {
            var Latitude = double.Parse("0");
            var Longitude = double.Parse("0");
            var request = new GeolocationRequest(GeolocationAccuracy.Best);
            var location = await Geolocation.GetLocationAsync(request);

            if (location != null)
            {
                Latitude = location.Latitude;
                Longitude = location.Longitude;
            }
            string url = urlOriginal.Replace("Coordenadas=ExactasCoordenadas", "Coordenadas=" + Latitude.ToString() + "," + Longitude.ToString());
            Navegador.Source = url;
        }
    }
}
